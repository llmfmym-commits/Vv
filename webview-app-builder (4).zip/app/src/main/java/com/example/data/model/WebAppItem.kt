package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "web_apps")
data class WebAppItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // "WEB_URL", "HTML", "ZIP_PROJECT"
    val targetUrl: String, // URL or absolute file path to index.html
    val iconPath: String? = null,
    val iconPreset: String? = null, // fallback color or icon name
    val pageIndex: Int = 0,
    val orderIndex: Int = 0,
    val folderId: Long? = null, // null if on home page grid
    val isLocked: Boolean = false,
    val pinCode: String? = null,
    val isHidden: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastUsedAt: Long = 0,

    // WebView Settings per App
    val javascriptEnabled: Boolean = true,
    val zoomEnabled: Boolean = true,
    val desktopMode: Boolean = false,
    val customUserAgent: String? = null,
    val cookiesEnabled: Boolean = true,
    val cacheEnabled: Boolean = true,
    val fullScreen: Boolean = false,
    val isIncognito: Boolean = false
)
