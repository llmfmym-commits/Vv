package com.example.data.apkbuilder

enum class ScreenOrientationOption(val displayNameFa: String, val manifestValue: String) {
    UNSPECIFIED("خودکار / آزاد (Auto)", "unspecified"),
    PORTRAIT("عمودی (Portrait)", "portrait"),
    LANDSCAPE("افقی (Landscape)", "landscape"),
    SENSOR("بر اساس چرخش حسگر (Sensor)", "sensor")
}

data class ApkPermissionsConfig(
    val camera: Boolean = false,
    val microphone: Boolean = false,
    val location: Boolean = false,
    val storage: Boolean = false,
    val vibration: Boolean = true
)

enum class SigningType(val titleFa: String) {
    DEBUG("امضای پیش‌فرض دیباگ (Debug Keystore)"),
    RELEASE("امضای اختصاصی انتشار (Custom Release Keystore)")
}

data class ReleaseKeystoreConfig(
    val keystorePath: String = "",
    val keyAlias: String = "",
    val storePassword: String = "",
    val keyPassword: String = ""
)

enum class BuildEngineMode(val titleFa: String, val descriptionFa: String) {
    LOCAL_PREPARATION(
        "آماده‌سازی سورس کامل پروژه اندروید (Local Project Packager)",
        "استخراج تمپلیت رسمی، پیکربندی مانیفست و وب‌اپ و تولید فایل ZIP پروژهٔ آماده برای بیلد در Android Studio و GitHub Actions"
    ),
    REMOTE_SERVER(
        "کامپایل از طریق سرور بیلد اختصاصی (Remote Build Server)",
        "ارسال پکیج به وب‌هوک/سرور بیلد ابری جهت کامپایل واقعی Gradle و دانلود مستقیم فایل APK نهایی"
    )
}

data class ApkBuildConfig(
    val webappId: Long = 0,
    val appName: String = "My Web App",
    val packageName: String = "com.webapp.app",
    val versionCode: Int = 1,
    val versionName: String = "1.0.0",
    val appIconUri: String? = null,
    val appIconColor: Long? = null,
    val appIconName: String? = null,
    val orientation: ScreenOrientationOption = ScreenOrientationOption.UNSPECIFIED,
    val permissions: ApkPermissionsConfig = ApkPermissionsConfig(),
    val pullToRefresh: Boolean = false,
    val clearCacheOnExit: Boolean = false,
    val signingType: SigningType = SigningType.DEBUG,
    val releaseKeystore: ReleaseKeystoreConfig? = null,
    val buildEngineMode: BuildEngineMode = BuildEngineMode.LOCAL_PREPARATION,
    val serverEndpoint: String = ""
)
