package com.example.data.apkbuilder

import android.content.Context
import com.example.data.model.WebAppItem
import kotlinx.coroutines.delay
import java.io.File

/**
 * Local Project Packager Engine.
 *
 * Full Gradle/SDK compilation natively on an Android device is technically not feasible
 * without a multi-gigabyte Linux rootfs / Termux environment.
 *
 * This engine extracts the official apk-template.zip, injects all configuration,
 * package identifiers, icons, assets, GitHub Actions workflows, and creates a 100%
 * standalone, ready-to-build Android Studio / Gradle project archive.
 */
class LocalBuildEngine(
    private val context: Context,
    private val templateManager: TemplateProjectManager,
    private val webApp: WebAppItem
) : BuildEngine {

    override suspend fun executeBuild(
        config: ApkBuildConfig,
        onProgress: (BuildProgress) -> Unit
    ): BuildResult {
        val log = mutableListOf<String>()
        val timestamp = System.currentTimeMillis()
        val buildDir = File(context.filesDir, "${TemplateProjectManager.BUILDS_DIR_NAME}/local_$timestamp")
        buildDir.mkdirs()

        try {
            // Stage 1: Preparing
            onProgress(BuildProgress.Preparing("آماده‌سازی دایرکتوری و خواندن تمپلیت استاندارد..."))
            log.add("Initialized project workspace: ${buildDir.absolutePath}")
            delay(350)

            // Stage 2: Extracting Template
            onProgress(BuildProgress.Extracting("در حال استخراج قالب Gradle از فایل apk-template.zip...", 0.25f))
            val sourceDir = templateManager.extractTemplate(buildDir) { p ->
                // extraction progress
            }
            log.add("Extracted clean template source to: ${sourceDir.absolutePath}")
            delay(400)

            // Stage 3: Configuring
            onProgress(BuildProgress.Configuring("پیکربندی هویت برنامه، مانیفست، مجوزها و وب‌اپ...", 0.6f))
            templateManager.configureProject(sourceDir, config, webApp) { p ->
                // config progress
            }
            log.add("Configured package: ${config.packageName}, appName: ${config.appName}, version: ${config.versionName}")
            delay(500)

            // Stage 4: Packaging Source Project ZIP
            onProgress(BuildProgress.Building("بسته‌بندی سورس کامل پروژه اندروید برای Android Studio و Gradle...", 0.85f))
            val safeName = config.appName.replace(Regex("[^a-zA-Z0-9_]"), "_")
            val projectZip = File(buildDir, "${safeName}_AndroidProject.zip")
            templateManager.packageSourceZip(sourceDir, projectZip)
            log.add("Standalone Android project archive created: ${projectZip.name} (${projectZip.length()} bytes)")
            delay(400)

            // Stage 5: Finalized
            val successMessage = "پروژهٔ سورس کامل اندروید با موفقیت آماده و بسته‌بندی شد! این فایل ZIP حاوی پروژهٔ کامل استاندارد Gradle، ورک‌فلوهای GitHub Actions و راهنمای بیلد است."
            val successProgress = BuildProgress.Completed(
                apkFile = null,
                projectZipFile = projectZip,
                message = successMessage,
                packageName = config.packageName,
                appName = config.appName,
                versionName = config.versionName
            )
            onProgress(successProgress)

            return BuildResult(
                success = true,
                outputFile = null,
                projectZipFile = projectZip,
                logMessages = log
            )
        } catch (e: Exception) {
            val errorMsg = e.message ?: "خطا در آماده‌سازی پروژه سورس"
            log.add("Build Error: $errorMsg")
            onProgress(BuildProgress.Failed(errorMsg, e.stackTraceToString()))
            return BuildResult(
                success = false,
                error = errorMsg,
                logMessages = log
            )
        }
    }
}
