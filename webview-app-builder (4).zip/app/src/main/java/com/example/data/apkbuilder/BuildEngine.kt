package com.example.data.apkbuilder

import java.io.File

sealed class BuildProgress {
    object Idle : BuildProgress()
    data class Preparing(val message: String) : BuildProgress()
    data class Extracting(val message: String, val progress: Float) : BuildProgress()
    data class Configuring(val message: String, val progress: Float) : BuildProgress()
    data class Building(val message: String, val progress: Float) : BuildProgress()
    data class Signing(val message: String, val progress: Float) : BuildProgress()
    data class Completed(
        val apkFile: File? = null,
        val projectZipFile: File? = null,
        val message: String,
        val packageName: String,
        val appName: String,
        val versionName: String
    ) : BuildProgress()
    data class Failed(val error: String, val details: String? = null) : BuildProgress()
}

data class BuildResult(
    val success: Boolean,
    val outputFile: File? = null,
    val projectZipFile: File? = null,
    val error: String? = null,
    val logMessages: List<String> = emptyList()
)

interface BuildEngine {
    suspend fun executeBuild(
        config: ApkBuildConfig,
        onProgress: (BuildProgress) -> Unit
    ): BuildResult
}
