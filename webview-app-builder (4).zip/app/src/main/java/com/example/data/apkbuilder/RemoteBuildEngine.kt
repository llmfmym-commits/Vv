package com.example.data.apkbuilder

import android.content.Context
import com.example.data.model.WebAppItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class RemoteBuildEngine(
    private val context: Context,
    private val templateManager: TemplateProjectManager,
    private val webApp: WebAppItem
) : BuildEngine {

    companion object {
        const val DEFAULT_PLACEHOLDER_ENDPOINT = "https://build-api.webapp-builder.app/v1/build"
    }

    override suspend fun executeBuild(
        config: ApkBuildConfig,
        onProgress: (BuildProgress) -> Unit
    ): BuildResult = withContext(Dispatchers.IO) {
        val log = mutableListOf<String>()
        val timestamp = System.currentTimeMillis()
        val buildDir = File(context.filesDir, "${TemplateProjectManager.BUILDS_DIR_NAME}/remote_$timestamp")
        buildDir.mkdirs()

        var projectZip: File? = null

        try {
            // Stage 1: Preparing
            onProgress(BuildProgress.Preparing("آماده‌سازی پکیج سورس پروژه جهت ارسال به سرور بیلد..."))
            log.add("Initialized remote build session: $timestamp")
            delay(350)

            // Stage 2: Extracting Template
            onProgress(BuildProgress.Extracting("استخراج تمپلیت استاندارد Gradle از مخزن apk-template.zip...", 0.2f))
            val sourceDir = templateManager.extractTemplate(buildDir)
            log.add("Extracted gradle template to: ${sourceDir.absolutePath}")
            delay(400)

            // Stage 3: Configuring
            onProgress(BuildProgress.Configuring("پیکربندی هویت برنامه، مجوزها و محتوای وب‌اپ...", 0.45f))
            templateManager.configureProject(sourceDir, config, webApp)
            log.add("Configured parameters: id=${config.packageName}, v=${config.versionName}")
            delay(400)

            // Stage 4: Package Project Archive
            val safeName = config.appName.replace(Regex("[^a-zA-Z0-9_]"), "_")
            val zipFile = File(buildDir, "${safeName}_BuildPayload.zip")
            templateManager.packageSourceZip(sourceDir, zipFile)
            projectZip = zipFile
            log.add("Packaged remote upload payload: ${zipFile.name} (${zipFile.length()} bytes)")
            delay(400)

            // Stage 5: Check endpoint configuration
            val endpoint = config.serverEndpoint.trim()
            val isCustomEndpoint = endpoint.isNotBlank() && endpoint != DEFAULT_PLACEHOLDER_ENDPOINT

            if (!isCustomEndpoint) {
                // Honest notification: No custom server endpoint configured
                val message = "آدرس سرور بیلد اختصاصی تنظیم نشده است. لطفاً آدرس سرور یا وب‌هوک بیلد خود را در تنظیمات وارد نمایید، یا از حالت «آماده‌سازی پکیج سورس محلی» برای دریافت فایل ZIP و بیلد رایگان با GitHub Actions استفاده کنید."
                log.add("Build Server not configured (default placeholder detected: $endpoint)")
                onProgress(BuildProgress.Failed(message))
                return@withContext BuildResult(
                    success = false,
                    projectZipFile = zipFile,
                    error = message,
                    logMessages = log
                )
            }

            // Stage 6: Attempting real dispatch to remote build server
            onProgress(BuildProgress.Building("در حال ارسال بسته به سرور بیلد ابری ($endpoint)...", 0.7f))
            log.add("Connecting to remote build server: $endpoint")

            val apkFile = File(buildDir, "${safeName}-v${config.versionName}.apk")
            val buildSuccessful = tryDispatchToServer(endpoint, zipFile, apkFile, log)

            if (!buildSuccessful || !apkFile.exists() || apkFile.length() == 0L) {
                throw IllegalStateException("سرور بیلد پاسخی معتبر نداد یا فایل APK دریافت نشد.")
            }

            // Stage 7: Completed
            onProgress(BuildProgress.Signing("تأیید امضای دیجیتال و دریافت نهایی فایل APK...", 0.95f))
            delay(300)

            val resultProgress = BuildProgress.Completed(
                apkFile = apkFile,
                projectZipFile = zipFile,
                message = "کامپایل و ساخت فایل APK توسط سرور بیلد راه دور با موفقیت انجام شد.",
                packageName = config.packageName,
                appName = config.appName,
                versionName = config.versionName
            )
            onProgress(resultProgress)

            return@withContext BuildResult(
                success = true,
                outputFile = apkFile,
                projectZipFile = zipFile,
                logMessages = log
            )
        } catch (e: Exception) {
            val errorMsg = e.message ?: "خطا در برقراری ارتباط با سرویس بیلد راه دور"
            log.add("Remote Build Error: $errorMsg")
            onProgress(BuildProgress.Failed(errorMsg, e.stackTraceToString()))
            return@withContext BuildResult(
                success = false,
                projectZipFile = projectZip,
                error = errorMsg,
                logMessages = log
            )
        }
    }

    private fun tryDispatchToServer(
        endpoint: String,
        payloadZip: File,
        targetApk: File,
        log: MutableList<String>
    ): Boolean {
        return try {
            val url = URL(endpoint)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 30000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/zip")
            conn.setRequestProperty("Content-Length", payloadZip.length().toString())

            FileInputStream(payloadZip).use { fis ->
                conn.outputStream.use { os ->
                    fis.copyTo(os)
                }
            }

            val responseCode = conn.responseCode
            log.add("Server response code: $responseCode")

            if (responseCode == HttpURLConnection.HTTP_OK) {
                conn.inputStream.use { ins ->
                    FileOutputStream(targetApk).use { fos ->
                        ins.copyTo(fos)
                    }
                }
                // Validate that the returned file is actually a valid ZIP/APK (starts with PK)
                if (targetApk.exists() && targetApk.length() > 4) {
                    val header = ByteArray(2)
                    FileInputStream(targetApk).use { it.read(header) }
                    val isValidZip = header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
                    if (isValidZip) {
                        log.add("Received verified APK artifact (${targetApk.length()} bytes)")
                        return true
                    }
                }
            }
            false
        } catch (e: Exception) {
            log.add("Network dispatch failed: ${e.message}")
            false
        }
    }
}
