package com.example.ui.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppSettings
import com.example.data.model.WebAppItem
import kotlinx.coroutines.launch

@Composable
fun SettingsDialog(
    currentSettings: AppSettings,
    hiddenApps: List<WebAppItem>,
    onDismiss: () -> Unit,
    onSaveSettings: (AppSettings) -> Unit,
    onUnhideApp: (WebAppItem) -> Unit,
    onExportBackup: suspend () -> String,
    onRestoreBackup: suspend (String) -> Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var appLockEnabled by remember { mutableStateOf(currentSettings.appLockEnabled) }
    var masterPin by remember { mutableStateOf(currentSettings.masterPin) }
    var restoreInputJson by remember { mutableStateOf("") }
    var showRestoreField by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = Color(0xFF38BDF8))
                Spacer(modifier = Modifier.width(8.dp))
                Text("تنظیمات و پشتیبان‌گیری", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section: App Lock
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("قفل کلی برنامه (App Lock)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }
                            Switch(
                                checked = appLockEnabled,
                                onCheckedChange = { appLockEnabled = it }
                            )
                        }

                        if (appLockEnabled) {
                            OutlinedTextField(
                                value = masterPin,
                                onValueChange = { if (it.length <= 8) masterPin = it },
                                label = { Text("رمز عبور اصلی (PIN)") },
                                placeholder = { Text("مثلاً 1234") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Section: Backup & Restore
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Backup, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("پشتیبان‌گیری و بازیابی (Backup & Restore)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        val json = onExportBackup()
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("WebViewAppBuilder_Backup", json))

                                        // Share intent
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_SUBJECT, "WebView App Builder Backup")
                                            putExtra(Intent.EXTRA_TEXT, json)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "ارسال پشتیبان"))
                                        Toast.makeText(context, "کد پشتیبان کپی شد و آماده اشتراک است", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("خروجی Backup", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { showRestoreField = !showRestoreField },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("بازیابی Restore", fontSize = 12.sp)
                            }
                        }

                        if (showRestoreField) {
                            OutlinedTextField(
                                value = restoreInputJson,
                                onValueChange = { restoreInputJson = it },
                                label = { Text("کد JSON پشتیبان") },
                                modifier = Modifier.fillMaxWidth().height(100.dp),
                                maxLines = 4
                            )

                            Button(
                                onClick = {
                                    if (restoreInputJson.isNotBlank()) {
                                        scope.launch {
                                            val success = onRestoreBackup(restoreInputJson)
                                            if (success) {
                                                Toast.makeText(context, "اطلاعات با موفقیت بازیابی شد", Toast.LENGTH_LONG).show()
                                                onDismiss()
                                            } else {
                                                Toast.makeText(context, "خطا در خواندن فایل پشتیبان", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("اجرای بازیابی")
                            }
                        }
                    }
                }

                // Section: Hidden Apps
                if (hiddenApps.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Visibility, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("برنامه‌های مخفی‌شده (${hiddenApps.size})", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }

                            hiddenApps.forEach { app ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(app.name, color = Color.White, fontSize = 13.sp)
                                    TextButton(onClick = { onUnhideApp(app) }) {
                                        Text("نمایش مجدد", fontSize = 12.sp, color = Color(0xFF38BDF8))
                                    }
                                }
                            }
                        }
                    }
                }

                // About
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("WebView App Builder v1.0", fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8), fontSize = 13.sp)
                        Text(
                            "Kotlin + Java + Jetpack Compose + Modern WebView + Offline HTML Engine",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSaveSettings(
                        currentSettings.copy(
                            appLockEnabled = appLockEnabled,
                            masterPin = masterPin
                        )
                    )
                    onDismiss()
                }
            ) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("بستن")
            }
        }
    )
}
