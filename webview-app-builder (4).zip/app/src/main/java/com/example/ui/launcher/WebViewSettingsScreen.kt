package com.example.ui.launcher

import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebViewSettingsScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()

    var jsEnabled by remember(settings.jsEnabledGlobal) { mutableStateOf(settings.jsEnabledGlobal) }
    var cookiesEnabled by remember(settings.cookiesEnabledGlobal) { mutableStateOf(settings.cookiesEnabledGlobal) }
    var localStorageEnabled by remember(settings.localStorageEnabledGlobal) { mutableStateOf(settings.localStorageEnabledGlobal) }
    var zoomEnabled by remember(settings.zoomEnabledGlobal) { mutableStateOf(settings.zoomEnabledGlobal) }
    var incognito by remember(settings.incognitoGlobal) { mutableStateOf(settings.incognitoGlobal) }
    var desktopMode by remember(settings.desktopModeGlobal) { mutableStateOf(settings.desktopModeGlobal) }
    var userAgent by remember(settings.userAgentGlobal) { mutableStateOf(settings.userAgentGlobal) }

    var showDesktopMenu by remember { mutableStateOf(false) }
    var showUserAgentMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تنظیمات WebView",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { /* more */ }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        containerColor = Color(0xFF0B101E)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // JavaScript Toggle
            SettingSwitchRow(
                icon = Icons.Default.Code,
                title = "JavaScript",
                checked = jsEnabled,
                onCheckedChange = {
                    jsEnabled = it
                    viewModel.updateSettings(settings.copy(jsEnabledGlobal = it))
                }
            )

            // Cookies Toggle
            SettingSwitchRow(
                icon = Icons.Default.Cookie,
                title = "Cookies",
                checked = cookiesEnabled,
                onCheckedChange = {
                    cookiesEnabled = it
                    viewModel.updateSettings(settings.copy(cookiesEnabledGlobal = it))
                }
            )

            // Local Storage Toggle
            SettingSwitchRow(
                icon = Icons.Default.Storage,
                title = "Local Storage",
                checked = localStorageEnabled,
                onCheckedChange = {
                    localStorageEnabled = it
                    viewModel.updateSettings(settings.copy(localStorageEnabledGlobal = it))
                }
            )

            // Zoom Toggle
            SettingSwitchRow(
                icon = Icons.Default.ZoomIn,
                title = "Zoom",
                checked = zoomEnabled,
                onCheckedChange = {
                    zoomEnabled = it
                    viewModel.updateSettings(settings.copy(zoomEnabledGlobal = it))
                }
            )

            // حالت Desktop (Dropdown)
            SettingDropdownRow(
                icon = Icons.Default.Computer,
                title = "حالت Desktop",
                selectedValue = if (desktopMode) "Desktop" else "Mobile",
                onClick = { showDesktopMenu = true }
            ) {
                DropdownMenu(
                    expanded = showDesktopMenu,
                    onDismissRequest = { showDesktopMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Mobile") },
                        onClick = {
                            desktopMode = false
                            viewModel.updateSettings(settings.copy(desktopModeGlobal = false))
                            showDesktopMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Desktop") },
                        onClick = {
                            desktopMode = true
                            viewModel.updateSettings(settings.copy(desktopModeGlobal = true))
                            showDesktopMenu = false
                        }
                    )
                }
            }

            // User-Agent (Dropdown)
            SettingDropdownRow(
                icon = Icons.Default.Person,
                title = "User-Agent",
                selectedValue = userAgent,
                onClick = { showUserAgentMenu = true }
            ) {
                DropdownMenu(
                    expanded = showUserAgentMenu,
                    onDismissRequest = { showUserAgentMenu = false }
                ) {
                    listOf("Mobile", "Desktop Chrome", "iPad / Tablet", "Custom").forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item) },
                            onClick = {
                                userAgent = item
                                viewModel.updateSettings(settings.copy(userAgentGlobal = item))
                                showUserAgentMenu = false
                            }
                        )
                    }
                }
            }

            // Incognito Toggle
            SettingSwitchRow(
                icon = Icons.Default.VisibilityOff,
                title = "Incognito",
                checked = incognito,
                onCheckedChange = {
                    incognito = it
                    viewModel.updateSettings(settings.copy(incognitoGlobal = it))
                }
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Action Buttons: پاک کردن کش and پاک کردن کوکی‌ها (matching mockup screen 9)
            Button(
                onClick = {
                    WebStorage.getInstance().deleteAllData()
                    Toast.makeText(context, "حافظه کش با موفقیت پاک شد", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
            ) {
                Text(
                    text = "پاک کردن کش",
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    Toast.makeText(context, "تمامی کوکی‌ها پاک شدند", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
            ) {
                Text(
                    text = "پاک کردن کوکی‌ها",
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF3B82F6),
                uncheckedThumbColor = Color(0xFF94A3B8),
                uncheckedTrackColor = Color(0xFF334155)
            )
        )
    }
}

@Composable
fun SettingDropdownRow(
    icon: ImageVector,
    title: String,
    selectedValue: String,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Box {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = selectedValue,
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "⌵",
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp
                )
            }
            content()
        }
    }
}
