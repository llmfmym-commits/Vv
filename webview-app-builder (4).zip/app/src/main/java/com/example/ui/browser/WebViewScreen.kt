package com.example.ui.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.View
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.model.DownloadItem
import com.example.data.model.WebAppItem
import com.example.ui.keyboard.CustomInAppKeyboard
import com.example.util.LocalAppStrings
import com.example.util.WebProfileManager
import com.example.viewmodel.AppViewModel

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(
    appItem: WebAppItem,
    viewModel: AppViewModel,
    onCloseBrowser: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenTabs: () -> Unit = {},
    onOpenBookmarks: () -> Unit = {},
    tabsCount: Int = 1
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var currentUrl by remember { mutableStateOf(appItem.targetUrl) }
    var pageTitle by remember { mutableStateOf(appItem.name) }
    var loadProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var isDesktopMode by remember { mutableStateOf(appItem.desktopMode) }
    var isFullScreen by remember { mutableStateOf(appItem.fullScreen) }
    var showMenu by remember { mutableStateOf(false) }
    var showCustomKeyboard by remember { mutableStateOf(false) }

    // Error states
    var hasNetworkError by remember { mutableStateOf(false) }
    var isProcessCrashed by remember { mutableStateOf(false) }

    // File chooser callback holder
    var filePathCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val fileChooserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val data = result.data
            val uris: Array<Uri>? = when {
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            filePathCallback?.onReceiveValue(uris)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    // Permission request holder for Camera / Mic
    var activePermissionRequest by remember { mutableStateOf<PermissionRequest?>(null) }

    val mediaPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        val grantedResources = mutableListOf<String>()
        if (cameraGranted) grantedResources.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
        if (audioGranted) grantedResources.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)

        if (grantedResources.isNotEmpty()) {
            activePermissionRequest?.grant(grantedResources.toTypedArray())
        } else {
            activePermissionRequest?.deny()
        }
        activePermissionRequest = null
    }

    // Handle Android system back key:
    // First dismiss in-app keyboard if open, then navigate history in WebView, then exit to Home
    BackHandler {
        if (showCustomKeyboard) {
            showCustomKeyboard = false
        } else if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            onCloseBrowser()
        }
    }

    DisposableEffect(appItem.id) {
        onDispose {
            if (appItem.isIncognito) {
                // Clear session cookies and cache if incognito
                webViewInstance?.clearCache(true)
                webViewInstance?.clearHistory()
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
            }
        }
    }

    // JS helper executor for in-app keyboard
    val executeJsScript: (String) -> Unit = { script ->
        webViewInstance?.evaluateJavascript(script, null)
    }

    val typeCharOnWeb: (String) -> Unit = { char ->
        val escaped = char.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")
        val script = """
            (function() {
                var el = document.activeElement;
                if (!el) return;
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    var start = el.selectionStart || 0;
                    var end = el.selectionEnd || 0;
                    var val = el.value || '';
                    el.value = val.substring(0, start) + '$escaped' + val.substring(end);
                    el.selectionStart = el.selectionEnd = start + '$escaped'.length;
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                } else if (el.isContentEditable) {
                    document.execCommand('insertText', false, '$escaped');
                }
            })();
        """.trimIndent()
        executeJsScript(script)
    }

    val backspaceOnWeb: () -> Unit = {
        val script = """
            (function() {
                var el = document.activeElement;
                if (!el) return;
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    var start = el.selectionStart || 0;
                    var end = el.selectionEnd || 0;
                    var val = el.value || '';
                    if (start === end && start > 0) {
                        el.value = val.substring(0, start - 1) + val.substring(end);
                        el.selectionStart = el.selectionEnd = start - 1;
                    } else if (start !== end) {
                        el.value = val.substring(0, start) + val.substring(end);
                        el.selectionStart = el.selectionEnd = start;
                    }
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                } else if (el.isContentEditable) {
                    document.execCommand('delete', false, null);
                }
            })();
        """.trimIndent()
        executeJsScript(script)
    }

    val enterOnWeb: () -> Unit = {
        val script = """
            (function() {
                var el = document.activeElement;
                if (!el) return;
                var event = new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true });
                el.dispatchEvent(event);
                if (el.form) {
                    el.form.submit();
                }
            })();
        """.trimIndent()
        executeJsScript(script)
    }

    Column(modifier = modifier.fillMaxSize().background(Color(0xFF0F172A))) {
        // Toolbar (hidden in full-screen mode)
        if (!isFullScreen) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF1E293B),
                shadowElevation = 4.dp
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onCloseBrowser) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = strings.home,
                                tint = Color(0xFF38BDF8)
                            )
                        }

                        IconButton(
                            onClick = { webViewInstance?.goBack() },
                            enabled = canGoBack
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = strings.back,
                                tint = if (canGoBack) Color.White else Color(0xFF64748B)
                            )
                        }

                        IconButton(
                            onClick = { webViewInstance?.goForward() },
                            enabled = canGoForward
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = strings.forward,
                                tint = if (canGoForward) Color.White else Color(0xFF64748B)
                            )
                        }

                        IconButton(onClick = {
                            hasNetworkError = false
                            isProcessCrashed = false
                            webViewInstance?.reload()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = strings.refresh,
                                tint = Color.White
                            )
                        }

                        // Title & URL container
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (currentUrl.startsWith("https://") || currentUrl.startsWith("file://")) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Secure",
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(
                                    text = pageTitle.ifBlank { appItem.name },
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = currentUrl,
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Bookmarks Button
                        IconButton(
                            onClick = {
                                viewModel.addBookmark(pageTitle.ifBlank { appItem.name }, currentUrl)
                                Toast.makeText(context, strings.bookmarkAdded, Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bookmark,
                                contentDescription = strings.bookmarks,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Tabs Count Badge Button
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .size(24.dp)
                                .border(1.5.dp, Color.White, RoundedCornerShape(6.dp))
                                .clickable(onClick = onOpenTabs),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$tabsCount",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Keyboard Toggle Button
                        IconButton(onClick = { showCustomKeyboard = !showCustomKeyboard }) {
                            Icon(
                                imageVector = Icons.Default.Keyboard,
                                contentDescription = strings.keyboard,
                                tint = if (showCustomKeyboard) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                            )
                        }

                        // Fullscreen Button
                        IconButton(onClick = { isFullScreen = true }) {
                            Icon(
                                imageVector = Icons.Default.Fullscreen,
                                contentDescription = strings.fullscreen,
                                tint = Color.White
                            )
                        }

                        // Overflow Menu
                        Box {
                            IconButton(onClick = { showMenu = true }) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = strings.settings,
                                    tint = Color.White
                                )
                            }

                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(if (isDesktopMode) strings.mobileMode else strings.desktopMode) },
                                    onClick = {
                                        isDesktopMode = !isDesktopMode
                                        webViewInstance?.settings?.userAgentString = if (isDesktopMode) {
                                            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                                        } else {
                                            WebSettings.getDefaultUserAgent(context)
                                        }
                                        webViewInstance?.reload()
                                        showMenu = false
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = if (isDesktopMode) Icons.Default.Smartphone else Icons.Default.Computer,
                                            contentDescription = null
                                        )
                                    }
                                )

                                DropdownMenuItem(
                                    text = { Text(strings.copyUrl) },
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("URL", currentUrl))
                                        Toast.makeText(context, strings.urlCopied, Toast.LENGTH_SHORT).show()
                                        showMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) }
                                )

                                DropdownMenuItem(
                                    text = { Text(strings.share) },
                                    onClick = {
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_TEXT, currentUrl)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, strings.share))
                                        showMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
                                )

                                DropdownMenuItem(
                                    text = { Text(strings.openInBrowser) },
                                    onClick = {
                                        try {
                                            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))
                                            context.startActivity(browserIntent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                        showMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.OpenInBrowser, contentDescription = null) }
                                )

                                DropdownMenuItem(
                                    text = { Text(strings.clearAppData) },
                                    onClick = {
                                        viewModel.clearWebAppData(appItem.id)
                                        webViewInstance?.clearCache(true)
                                        webViewInstance?.reload()
                                        Toast.makeText(context, strings.clearDataSuccess, Toast.LENGTH_SHORT).show()
                                        showMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) }
                                )
                            }
                        }
                    }

                    if (isLoading) {
                        LinearProgressIndicator(
                            progress = { loadProgress },
                            modifier = Modifier.fillMaxWidth().height(2.dp),
                            color = Color(0xFF38BDF8),
                            trackColor = Color.Transparent
                        )
                    }
                }
            }
        } else {
            // Floating exit full-screen button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                contentAlignment = Alignment.TopEnd
            ) {
                IconButton(
                    onClick = { isFullScreen = false },
                    modifier = Modifier.background(Color(0x88000000), shape = CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.FullscreenExit,
                        contentDescription = strings.exitFullscreen,
                        tint = Color.White
                    )
                }
            }
        }

        // Web Content View / Error Screens
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (isProcessCrashed) {
                // Page Crashed Overlay
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = strings.pageCrashed,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = strings.pageCrashedDesc,
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                isProcessCrashed = false
                                webViewInstance?.reload()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                        ) {
                            Text(strings.retry)
                        }
                        Button(
                            onClick = onCloseBrowser,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                        ) {
                            Text(strings.home)
                        }
                    }
                }
            } else if (hasNetworkError) {
                // No Internet Overlay
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = strings.noInternet,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = strings.noInternetDesc,
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                hasNetworkError = false
                                webViewInstance?.reload()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                        ) {
                            Text(strings.retry)
                        }
                        Button(
                            onClick = onCloseBrowser,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                        ) {
                            Text(strings.home)
                        }
                    }
                }
            } else {
                // Primary WebView (DIRECT ROOT SCROLL CONTAINER — NO PARENT SCROLL MODIFIERS)
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewInstance = this

                            // Performance & touch responsiveness
                            setLayerType(View.LAYER_TYPE_HARDWARE, null)
                            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
                            isNestedScrollingEnabled = true
                            isFocusable = true
                            isFocusableInTouchMode = true
                            isLongClickable = true
                            isHapticFeedbackEnabled = true
                            isScrollbarFadingEnabled = true
                            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY

                            // Multi-profile isolation per Web App!
                            WebProfileManager.applyProfileToWebView(
                                this,
                                appItem.id,
                                appItem.cookiesEnabled,
                                appItem.isIncognito
                            )

                            // Comprehensive modern WebSettings
                            settings.apply {
                                javaScriptEnabled = appItem.javascriptEnabled
                                domStorageEnabled = true
                                databaseEnabled = true
                                allowFileAccess = true
                                allowContentAccess = true
                                mediaPlaybackRequiresUserGesture = false
                                setSupportMultipleWindows(true)
                                javaScriptCanOpenWindowsAutomatically = true
                                setSupportZoom(appItem.zoomEnabled)
                                builtInZoomControls = appItem.zoomEnabled
                                displayZoomControls = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                                cacheMode = if (appItem.cacheEnabled && !appItem.isIncognito) {
                                    WebSettings.LOAD_DEFAULT
                                } else {
                                    WebSettings.LOAD_NO_CACHE
                                }

                                if (isDesktopMode) {
                                    userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                                }
                            }

                            // Internal Navigation WebViewClient
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val url = request?.url?.toString() ?: return false
                                    val scheme = request.url.scheme?.lowercase() ?: ""

                                    // Keep all web & local file requests strictly inside internal WebView
                                    if (scheme == "http" || scheme == "https" || scheme == "file") {
                                        return false
                                    }

                                    // External intents for tel, mailto, etc.
                                    return try {
                                        val intent = Intent(Intent.ACTION_VIEW, request.url)
                                        ctx.startActivity(intent)
                                        true
                                    } catch (e: Exception) {
                                        false
                                    }
                                }

                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isLoading = true
                                    hasNetworkError = false
                                    url?.let { currentUrl = it }
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoading = false
                                    url?.let {
                                        currentUrl = it
                                        val title = view?.title ?: ""
                                        pageTitle = title
                                        viewModel.addHistory(title, it)
                                    }
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                    CookieManager.getInstance().flush()
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    error: WebResourceError?
                                ) {
                                    super.onReceivedError(view, request, error)
                                    if (request?.isForMainFrame == true) {
                                        hasNetworkError = true
                                    }
                                }

                                override fun onRenderProcessGone(
                                    view: WebView?,
                                    detail: RenderProcessGoneDetail?
                                ): Boolean {
                                    isProcessCrashed = true
                                    return true // Handled safely without crashing the Android app
                                }
                            }

                            // WebChromeClient for File Chooser, Progress, Fullscreen & Permissions
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    loadProgress = newProgress / 100f
                                    if (newProgress >= 100) isLoading = false
                                }

                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    super.onReceivedTitle(view, title)
                                    if (!title.isNullOrBlank()) pageTitle = title
                                }

                                override fun onShowFileChooser(
                                    webView: WebView?,
                                    filePathCallbackInternal: ValueCallback<Array<Uri>>?,
                                    fileChooserParams: FileChooserParams?
                                ): Boolean {
                                    filePathCallback?.onReceiveValue(null)
                                    filePathCallback = filePathCallbackInternal

                                    try {
                                        val acceptTypes = fileChooserParams?.acceptTypes?.filter { it.isNotBlank() }
                                        val isMultiple = fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE

                                        val intent: Intent = if (fileChooserParams != null) {
                                            try {
                                                fileChooserParams.createIntent()
                                            } catch (e: Exception) {
                                                Intent(Intent.ACTION_GET_CONTENT).apply {
                                                    addCategory(Intent.CATEGORY_OPENABLE)
                                                    type = "*/*"
                                                }
                                            }
                                        } else {
                                            Intent(Intent.ACTION_GET_CONTENT).apply {
                                                addCategory(Intent.CATEGORY_OPENABLE)
                                                type = "*/*"
                                            }
                                        }

                                        if (isMultiple) {
                                            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                                        }

                                        if (!acceptTypes.isNullOrEmpty()) {
                                            if (acceptTypes.size == 1) {
                                                intent.type = acceptTypes[0]
                                            } else {
                                                intent.type = "*/*"
                                                intent.putExtra(Intent.EXTRA_MIME_TYPES, acceptTypes.toTypedArray())
                                            }
                                        }

                                        val chooserIntent = Intent.createChooser(intent, "Upload File")
                                        fileChooserLauncher.launch(chooserIntent)
                                        return true
                                    } catch (e: Exception) {
                                        filePathCallback?.onReceiveValue(null)
                                        filePathCallback = null
                                        return false
                                    }
                                }

                                override fun onPermissionRequest(request: PermissionRequest?) {
                                    if (request == null) return
                                    activePermissionRequest = request

                                    val requiredPermissions = mutableListOf<String>()
                                    for (resource in request.resources) {
                                        if (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                                requiredPermissions.add(Manifest.permission.CAMERA)
                                            }
                                        }
                                        if (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                                requiredPermissions.add(Manifest.permission.RECORD_AUDIO)
                                            }
                                        }
                                    }

                                    if (requiredPermissions.isNotEmpty()) {
                                        mediaPermissionLauncher.launch(requiredPermissions.toTypedArray())
                                    } else {
                                        request.grant(request.resources)
                                    }
                                }
                            }

                            // Download Listener
                            setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                                try {
                                    val downloadId = WebProfileManager.enqueueDownload(
                                        ctx,
                                        url,
                                        userAgent,
                                        contentDisposition,
                                        mimeType,
                                        appItem.id
                                    )
                                    val fileName = Uri.parse(url).lastPathSegment ?: "download"
                                    viewModel.addDownload(
                                        DownloadItem(
                                            id = downloadId,
                                            fileName = fileName,
                                            fileUri = url,
                                            mimeType = mimeType ?: "*/*",
                                            timestamp = System.currentTimeMillis()
                                        )
                                    )
                                    Toast.makeText(ctx, "Download started: $fileName", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(ctx, "Download error: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }

                            // Load initial URL
                            if (appItem.targetUrl.startsWith("/")) {
                                loadUrl("file://" + appItem.targetUrl)
                            } else {
                                loadUrl(appItem.targetUrl)
                            }
                        }
                    }
                )
            }
        }

        // Custom In-App Keyboard Slide-up Panel (only visible when explicitly triggered)
        AnimatedVisibility(
            visible = showCustomKeyboard,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            CustomInAppKeyboard(
                onCharTyped = { ch -> typeCharOnWeb(ch) },
                onBackspace = { backspaceOnWeb() },
                onEnter = { enterOnWeb() },
                onDismiss = { showCustomKeyboard = false },
                initialLanguage = viewModel.settings.value.keyboardLanguage
            )
        }
    }
}
