package com.example.ui.launcher

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppSettings
import com.example.util.FileUtils

@Composable
fun AppearanceDialog(
    currentSettings: AppSettings,
    onDismiss: () -> Unit,
    onSaveSettings: (AppSettings) -> Unit
) {
    val context = LocalContext.current

    var wallpaperType by remember { mutableStateOf(currentSettings.wallpaperType) }
    var wallpaperValue by remember { mutableStateOf(currentSettings.wallpaperValue) }
    var themeMode by remember { mutableStateOf(currentSettings.themeMode) }
    var columnCount by remember { mutableIntStateOf(currentSettings.columnCount) }
    var iconShape by remember { mutableStateOf(currentSettings.iconShape) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val saved = FileUtils.saveIconFromUri(context, uri)
            if (saved != null) {
                wallpaperType = "IMAGE"
                wallpaperValue = saved
            }
        }
    }

    val solidColors = listOf(
        "#0F172A", "#1E293B", "#18181B", "#1C1917", "#022C22",
        "#172554", "#311042", "#450A0A", "#134E4A", "#262626"
    )

    val gradients = listOf(
        "GRADIENT_SUNSET" to Pair(Color(0xFFF97316), Color(0xFF9333EA)),
        "GRADIENT_OCEAN" to Pair(Color(0xFF0284C7), Color(0xFF0F172A)),
        "GRADIENT_AURORA" to Pair(Color(0xFF10B981), Color(0xFF065F46)),
        "GRADIENT_NEON" to Pair(Color(0xFF8B5CF6), Color(0xFFEC4899)),
        "GRADIENT_MIDNIGHT" to Pair(Color(0xFF1E1B4B), Color(0xFF020617))
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Palette, contentDescription = null, tint = Color(0xFF38BDF8))
                Spacer(modifier = Modifier.width(8.dp))
                Text("شخصی‌سازی و ظاهر", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Wallpaper Type Selection
                Text("پس‌زمینه صفحه اصلی (Wallpaper):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = wallpaperType == "DEFAULT",
                        onClick = {
                            wallpaperType = "DEFAULT"
                            wallpaperValue = ""
                        },
                        label = { Text("پیش‌فرض", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = wallpaperType == "COLOR",
                        onClick = {
                            wallpaperType = "COLOR"
                            if (wallpaperValue.isEmpty()) wallpaperValue = solidColors.first()
                        },
                        label = { Text("رنگ ساده", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = wallpaperType == "GRADIENT",
                        onClick = {
                            wallpaperType = "GRADIENT"
                            if (wallpaperValue.isEmpty()) wallpaperValue = "GRADIENT_OCEAN"
                        },
                        label = { Text("گرادیانت", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = wallpaperType == "IMAGE",
                        onClick = {
                            imagePickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        label = { Text("گالری", fontSize = 11.sp) }
                    )
                }

                // Wallpaper Palette depending on choice
                if (wallpaperType == "COLOR") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        solidColors.forEach { hex ->
                            val isSelected = wallpaperValue.equals(hex, ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(hex)))
                                    .border(
                                        if (isSelected) 3.dp else 1.dp,
                                        if (isSelected) Color(0xFF38BDF8) else Color.Gray,
                                        CircleShape
                                    )
                                    .clickable { wallpaperValue = hex },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                } else if (wallpaperType == "GRADIENT") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        gradients.forEach { (key, colors) ->
                            val isSelected = wallpaperValue == key
                            Box(
                                modifier = Modifier
                                    .size(width = 54.dp, height = 38.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Brush.linearGradient(listOf(colors.first, colors.second)))
                                    .border(
                                        if (isSelected) 3.dp else 1.dp,
                                        if (isSelected) Color.White else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { wallpaperValue = key },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Theme Mode
                Text("تم برنامه (Theme):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = themeMode == "SYSTEM",
                        onClick = { themeMode = "SYSTEM" },
                        label = { Text("سیستم") }
                    )
                    FilterChip(
                        selected = themeMode == "DARK",
                        onClick = { themeMode = "DARK" },
                        label = { Text("تاریک (Dark)") }
                    )
                    FilterChip(
                        selected = themeMode == "LIGHT",
                        onClick = { themeMode = "LIGHT" },
                        label = { Text("روشن (Light)") }
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Column Count
                Text("تعداد ستون‌های آیکون:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(3, 4, 5).forEach { cols ->
                        FilterChip(
                            selected = columnCount == cols,
                            onClick = { columnCount = cols },
                            label = { Text("$cols ستون") }
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Icon Shape
                Text("شکل آیکون‌ها:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = iconShape == "ROUNDED_SQUARE",
                        onClick = { iconShape = "ROUNDED_SQUARE" },
                        label = { Text("مربع گرد") }
                    )
                    FilterChip(
                        selected = iconShape == "CIRCLE",
                        onClick = { iconShape = "CIRCLE" },
                        label = { Text("دایره") }
                    )
                    FilterChip(
                        selected = iconShape == "SQUIRCLE",
                        onClick = { iconShape = "SQUIRCLE" },
                        label = { Text("Squircle") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = currentSettings.copy(
                        wallpaperType = wallpaperType,
                        wallpaperValue = wallpaperValue,
                        themeMode = themeMode,
                        columnCount = columnCount,
                        iconShape = iconShape
                    )
                    onSaveSettings(updated)
                    onDismiss()
                }
            ) {
                Text("اعمال تنظیمات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}
