package com.example.ui.settings

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.WebAppItem
import com.example.util.LocalAppStrings
import com.example.viewmodel.AppViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit,
    onNavigateToAppearance: () -> Unit,
    onNavigateToWallpaper: () -> Unit,
    onNavigateToTabs: () -> Unit,
    onNavigateToBookmarks: () -> Unit,
    onNavigateToHtmlBuilder: () -> Unit,
    onNavigateToAddApp: () -> Unit,
    onOpenUrlInBrowser: (String) -> Unit,
    onNavigateToApkBuilder: () -> Unit = {}
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val scope = rememberCoroutineScope()

    val settings by viewModel.settings.collectAsState()
    val allApps by viewModel.allApps.collectAsState()
    val allFolders by viewModel.allFolders.collectAsState()
    val historyList by viewModel.history.collectAsState()
    val downloadsList by viewModel.downloads.collectAsState()

    // Dialog controllers
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showKeyboardDialog by remember { mutableStateOf(false) }
    var showBrowserDialog by remember { mutableStateOf(false) }
    var showWebViewDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showDownloadsDialog by remember { mutableStateOf(false) }
    var showWebAppsDialog by remember { mutableStateOf(false) }
    var showHtmlAppsDialog by remember { mutableStateOf(false) }
    var showFoldersDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var showPermissionsDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .statusBarsPadding()
    ) {
        // Header
        Surface(
            color = Color(0xFF1E293B),
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.back,
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = strings.settings,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Settings items list (19 sections)
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Feature: Convert Web App to APK
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onNavigateToApkBuilder),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF0284C7), Color(0xFF10B981))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Android,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "سازنده APK (تبدیل Web App به APK)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "تبدیل سایت‌ها و پروژه‌های HTML به پکیج واقعی و قابل نصب اندروید",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8),
                                lineHeight = 16.sp
                            )
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8)
                        )
                    }
                }
            }

            // 1. Appearance
            item {
                SettingsCardItem(
                    title = strings.appearance,
                    subtitle = "تم، اندازه آیکون‌ها، تعداد ستون‌ها و رنگ شاخص",
                    icon = Icons.Default.Palette,
                    iconTint = Color(0xFF38BDF8),
                    onClick = onNavigateToAppearance
                )
            }

            // 2. Language
            item {
                val currentLangLabel = when (settings.language) {
                    "FA" -> strings.persian
                    "EN" -> strings.english
                    "FR" -> strings.french
                    else -> strings.systemDefault
                }
                SettingsCardItem(
                    title = strings.language,
                    subtitle = currentLangLabel,
                    icon = Icons.Default.Language,
                    iconTint = Color(0xFF10B981),
                    onClick = { showLanguageDialog = true }
                )
            }

            // 3. Keyboard
            item {
                val keyboardLabel = if (settings.keyboardType == "APP") strings.appKeyboard else strings.systemKeyboard
                SettingsCardItem(
                    title = strings.keyboard,
                    subtitle = keyboardLabel,
                    icon = Icons.Default.Keyboard,
                    iconTint = Color(0xFFF59E0B),
                    onClick = { showKeyboardDialog = true }
                )
            }

            // 4. Browser
            item {
                SettingsCardItem(
                    title = strings.browser,
                    subtitle = "صفحه خانگی، موتور جستجو و اجرای مرورگر",
                    icon = Icons.Default.OpenInBrowser,
                    iconTint = Color(0xFF6366F1),
                    onClick = { showBrowserDialog = true }
                )
            }

            // 5. WebView
            item {
                SettingsCardItem(
                    title = strings.webview,
                    subtitle = "جاوااسکریپت، کوکی‌ها، کش و سشن‌های سراسری",
                    icon = Icons.Default.Web,
                    iconTint = Color(0xFF06B6D4),
                    onClick = { showWebViewDialog = true }
                )
            }

            // 6. Tabs
            item {
                SettingsCardItem(
                    title = strings.tabs,
                    subtitle = "مشاهده و مدیریت تب‌های فعال مرورگر",
                    icon = Icons.Default.Tab,
                    iconTint = Color(0xFFEC4899),
                    onClick = onNavigateToTabs
                )
            }

            // 7. Bookmarks
            item {
                SettingsCardItem(
                    title = strings.bookmarks,
                    subtitle = "سایت‌ها و صفحات ذخیره‌شده مورد علاقه",
                    icon = Icons.Default.Bookmark,
                    iconTint = Color(0xFFF43F5E),
                    onClick = onNavigateToBookmarks
                )
            }

            // 8. History
            item {
                SettingsCardItem(
                    title = strings.history,
                    subtitle = "${historyList.size} صفحه در تاریخچه مرور",
                    icon = Icons.Default.History,
                    iconTint = Color(0xFF8B5CF6),
                    onClick = { showHistoryDialog = true }
                )
            }

            // 9. Downloads
            item {
                SettingsCardItem(
                    title = strings.downloads,
                    subtitle = "${downloadsList.size} فایل دانلود شده",
                    icon = Icons.Default.Download,
                    iconTint = Color(0xFF14B8A6),
                    onClick = { showDownloadsDialog = true }
                )
            }

            // 10. Web Apps
            item {
                SettingsCardItem(
                    title = strings.webApps,
                    subtitle = "مدیریت و پروفایل‌های مستقل ${allApps.filter { it.type == "WEB_URL" }.size} برنامه وب",
                    icon = Icons.Default.Apps,
                    iconTint = Color(0xFF3B82F6),
                    onClick = { showWebAppsDialog = true }
                )
            }

            // 11. HTML Apps
            item {
                SettingsCardItem(
                    title = strings.htmlApps,
                    subtitle = "سازنده اپلیکیشن و پروژه‌های HTML آفلاین",
                    icon = Icons.Default.Code,
                    iconTint = Color(0xFFF97316),
                    onClick = { showHtmlAppsDialog = true }
                )
            }

            // 12. Folders
            item {
                SettingsCardItem(
                    title = strings.folders,
                    subtitle = "${allFolders.size} پوشه ساخته شده",
                    icon = Icons.Default.Folder,
                    iconTint = Color(0xFFEAB308),
                    onClick = { showFoldersDialog = true }
                )
            }

            // 13. Wallpaper
            item {
                SettingsCardItem(
                    title = strings.wallpaper,
                    subtitle = "تغییر تصویر، گرادیان یا شفافیت پس‌زمینه",
                    icon = Icons.Default.Wallpaper,
                    iconTint = Color(0xFFA855F7),
                    onClick = onNavigateToWallpaper
                )
            }

            // 14. Privacy
            item {
                SettingsCardItem(
                    title = strings.privacy,
                    subtitle = "حالت ناشناس، عدم ردیابی، پاک‌سازی اطلاعات",
                    icon = Icons.Default.PrivacyTip,
                    iconTint = Color(0xFF0284C7),
                    onClick = { showPrivacyDialog = true }
                )
            }

            // 15. Security
            item {
                SettingsCardItem(
                    title = strings.security,
                    subtitle = if (settings.appLockEnabled) "قفل با رمز فعال است" else "قفل برنامه و رمز مستر",
                    icon = Icons.Default.Security,
                    iconTint = Color(0xFF10B981),
                    onClick = { showSecurityDialog = true }
                )
            }

            // 16. Permissions
            item {
                SettingsCardItem(
                    title = strings.permissions,
                    subtitle = "وضعیت دسترسی‌های دوربین، میکروفون و دانلود",
                    icon = Icons.Default.VerifiedUser,
                    iconTint = Color(0xFF06B6D4),
                    onClick = { showPermissionsDialog = true }
                )
            }

            // 17. Backup & Restore
            item {
                SettingsCardItem(
                    title = strings.backupRestore,
                    subtitle = "خروجی کامل JSON از برنامه‌ها و تنظیمات",
                    icon = Icons.Default.Backup,
                    iconTint = Color(0xFF64748B),
                    onClick = { showBackupDialog = true }
                )
            }

            // 18. Notifications
            item {
                SettingsCardItem(
                    title = strings.notifications,
                    subtitle = "اعلان اتمام دانلود و اعلانات وب",
                    icon = Icons.Default.Notifications,
                    iconTint = Color(0xFFF59E0B),
                    onClick = {
                        Toast.makeText(context, "اعلان‌های سیستمی فعال هستند", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // 19. About
            item {
                SettingsCardItem(
                    title = strings.about,
                    subtitle = "نسخه ۱.۰.۰ — ساخته شده با Jetpack Compose",
                    icon = Icons.Default.Info,
                    iconTint = Color(0xFF94A3B8),
                    onClick = { showAboutDialog = true }
                )
            }
        }
    }

    // --- DIALOGS ---

    // 2. Language Dialog
    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text(strings.selectLanguage, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    listOf(
                        "SYSTEM" to strings.systemDefault,
                        "FA" to strings.persian,
                        "EN" to strings.english,
                        "FR" to strings.french
                    ).forEach { (code, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateSettings(settings.copy(language = code))
                                    showLanguageDialog = false
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = settings.language == code,
                                onClick = {
                                    viewModel.updateSettings(settings.copy(language = code))
                                    showLanguageDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF38BDF8))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(label, color = Color.White, fontSize = 15.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) {
                    Text(strings.close, color = Color(0xFF38BDF8))
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 3. Keyboard Dialog
    if (showKeyboardDialog) {
        AlertDialog(
            onDismissRequest = { showKeyboardDialog = false },
            title = { Text(strings.keyboardMode, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // System Keyboard Option
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (settings.keyboardType == "SYSTEM") Color(0xFF334155) else Color(0xFF1E293B)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.updateSettings(settings.copy(keyboardType = "SYSTEM"))
                            }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = settings.keyboardType == "SYSTEM",
                                    onClick = { viewModel.updateSettings(settings.copy(keyboardType = "SYSTEM")) },
                                    colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF38BDF8))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.systemKeyboard, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Text(
                                strings.systemKeyboardDesc,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(start = 36.dp)
                            )
                        }
                    }

                    // App Keyboard Option
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (settings.keyboardType == "APP") Color(0xFF334155) else Color(0xFF1E293B)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.updateSettings(settings.copy(keyboardType = "APP"))
                            }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = settings.keyboardType == "APP",
                                    onClick = { viewModel.updateSettings(settings.copy(keyboardType = "APP")) },
                                    colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF38BDF8))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.appKeyboard, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Text(
                                strings.appKeyboardDesc,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(start = 36.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showKeyboardDialog = false }) {
                    Text(strings.ok, color = Color(0xFF38BDF8))
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 4. Browser Settings Dialog
    if (showBrowserDialog) {
        var homeUrlInput by remember { mutableStateOf(settings.homePage) }
        var searchUrlInput by remember { mutableStateOf(settings.defaultSearchEngine) }

        AlertDialog(
            onDismissRequest = { showBrowserDialog = false },
            title = { Text(strings.browser, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = homeUrlInput,
                        onValueChange = { homeUrlInput = it },
                        label = { Text("صفحه اصلی (Home Page)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = searchUrlInput,
                        onValueChange = { searchUrlInput = it },
                        label = { Text("موتور جستجو (Search Engine URL)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            showBrowserDialog = false
                            onOpenUrlInBrowser(homeUrlInput)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                    ) {
                        Text("باز کردن مرورگر")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSettings(
                            settings.copy(
                                homePage = homeUrlInput,
                                defaultSearchEngine = searchUrlInput
                            )
                        )
                        showBrowserDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBrowserDialog = false }) {
                    Text(strings.cancel)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 5. WebView Settings Dialog
    if (showWebViewDialog) {
        var jsEnabled by remember { mutableStateOf(settings.jsEnabledGlobal) }
        var cookiesEnabled by remember { mutableStateOf(settings.cookiesEnabledGlobal) }
        var domStorageEnabled by remember { mutableStateOf(settings.localStorageEnabledGlobal) }
        var zoomEnabled by remember { mutableStateOf(settings.zoomEnabledGlobal) }
        var desktopMode by remember { mutableStateOf(settings.desktopModeGlobal) }

        AlertDialog(
            onDismissRequest = { showWebViewDialog = false },
            title = { Text(strings.webview, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.javascript, color = Color.White)
                        Switch(checked = jsEnabled, onCheckedChange = { jsEnabled = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.cookies, color = Color.White)
                        Switch(checked = cookiesEnabled, onCheckedChange = { cookiesEnabled = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.domStorage, color = Color.White)
                        Switch(checked = domStorageEnabled, onCheckedChange = { domStorageEnabled = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.zoom, color = Color.White)
                        Switch(checked = zoomEnabled, onCheckedChange = { zoomEnabled = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.desktopMode, color = Color.White)
                        Switch(checked = desktopMode, onCheckedChange = { desktopMode = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSettings(
                            settings.copy(
                                jsEnabledGlobal = jsEnabled,
                                cookiesEnabledGlobal = cookiesEnabled,
                                localStorageEnabledGlobal = domStorageEnabled,
                                zoomEnabledGlobal = zoomEnabled,
                                desktopModeGlobal = desktopMode
                            )
                        )
                        showWebViewDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWebViewDialog = false }) {
                    Text(strings.cancel)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 8. History Dialog
    if (showHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.history, fontWeight = FontWeight.Bold)
                    if (historyList.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearHistory() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear History", tint = Color(0xFFEF4444))
                        }
                    }
                }
            },
            text = {
                if (historyList.isEmpty()) {
                    Text("تاریخچه‌ای ثبت نشده است.", color = Color(0xFF94A3B8))
                } else {
                    LazyColumn(modifier = Modifier.height(300.dp)) {
                        items(historyList) { item ->
                            val dateStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(item.timestamp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        showHistoryDialog = false
                                        onOpenUrlInBrowser(item.url)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                        Text(item.url, color = Color(0xFF94A3B8), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text(dateStr, color = Color(0xFF64748B), fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistoryDialog = false }) {
                    Text(strings.close)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 9. Downloads Dialog
    if (showDownloadsDialog) {
        AlertDialog(
            onDismissRequest = { showDownloadsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.downloads, fontWeight = FontWeight.Bold)
                    if (downloadsList.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearDownloads() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear", tint = Color(0xFFEF4444))
                        }
                    }
                }
            },
            text = {
                if (downloadsList.isEmpty()) {
                    Text("فایل دانلودی ثبت نشده است.", color = Color(0xFF94A3B8))
                } else {
                    LazyColumn(modifier = Modifier.height(300.dp)) {
                        items(downloadsList) { item ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF14B8A6))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.fileName, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                                        Text(item.fileUri, color = Color(0xFF94A3B8), fontSize = 10.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDownloadsDialog = false }) {
                    Text(strings.close)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 10. Web Apps Dialog (with Multi-Profile indicator and Add button)
    if (showWebAppsDialog) {
        val webAppsList = allApps.filter { it.type == "WEB_URL" }
        AlertDialog(
            onDismissRequest = { showWebAppsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.webApps, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = {
                            showWebAppsDialog = false
                            onNavigateToAddApp()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.addApp, fontSize = 12.sp)
                    }
                }
            },
            text = {
                Column {
                    Text(
                        strings.independentProfileNotice,
                        color = Color(0xFF38BDF8),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    LazyColumn(modifier = Modifier.height(280.dp)) {
                        items(webAppsList) { app ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(app.name, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text("Profile: profile_${app.id}", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                    }
                                    IconButton(onClick = {
                                        viewModel.clearWebAppData(app.id)
                                        Toast.makeText(context, strings.clearDataSuccess, Toast.LENGTH_SHORT).show()
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Clear Data", tint = Color(0xFFF59E0B))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showWebAppsDialog = false }) {
                    Text(strings.close)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 11. HTML Apps Dialog
    if (showHtmlAppsDialog) {
        val htmlAppsList = allApps.filter { it.type == "HTML" || it.type == "ZIP" }
        AlertDialog(
            onDismissRequest = { showHtmlAppsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.htmlApps, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = {
                            showHtmlAppsDialog = false
                            onNavigateToHtmlBuilder()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF97316))
                    ) {
                        Text(strings.htmlBuilder, fontSize = 12.sp)
                    }
                }
            },
            text = {
                if (htmlAppsList.isEmpty()) {
                    Text("هیچ برنامه HTML آفلاینی ساخته نشده است.", color = Color(0xFF94A3B8))
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(htmlAppsList) { app ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFFF97316))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(app.name, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHtmlAppsDialog = false }) {
                    Text(strings.close)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 12. Folders Dialog
    if (showFoldersDialog) {
        var newFolderName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFoldersDialog = false },
            title = { Text(strings.folders, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newFolderName,
                            onValueChange = { newFolderName = it },
                            label = { Text("نام پوشه جدید") },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = {
                                if (newFolderName.isNotBlank()) {
                                    viewModel.createFolder(newFolderName, "#3B82F6")
                                    newFolderName = ""
                                }
                            }
                        ) {
                            Text(strings.addApp)
                        }
                    }
                    LazyColumn(modifier = Modifier.height(200.dp)) {
                        items(allFolders) { folder ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = Color(0xFFEAB308))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(folder.name, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { viewModel.deleteFolder(folder) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFoldersDialog = false }) {
                    Text(strings.close)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 14. Privacy Dialog
    if (showPrivacyDialog) {
        var incognito by remember { mutableStateOf(settings.incognitoGlobal) }
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text(strings.privacy, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.incognitoMode, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("عدم ذخیره کوکی‌ها و تاریخچه مرور", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                        Switch(checked = incognito, onCheckedChange = { incognito = it })
                    }
                    Button(
                        onClick = {
                            viewModel.clearHistory()
                            Toast.makeText(context, "تاریخچه مرور با موفقیت پاک شد", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("پاک‌سازی کامل تاریخچه و داده‌ها")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSettings(settings.copy(incognitoGlobal = incognito))
                        showPrivacyDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text(strings.cancel)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 15. Security Dialog
    if (showSecurityDialog) {
        var lockEnabled by remember { mutableStateOf(settings.appLockEnabled) }
        var pinInput by remember { mutableStateOf(settings.masterPin) }

        AlertDialog(
            onDismissRequest = { showSecurityDialog = false },
            title = { Text(strings.security, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.appLock, color = Color.White, fontWeight = FontWeight.Bold)
                        Switch(checked = lockEnabled, onCheckedChange = { lockEnabled = it })
                    }
                    if (lockEnabled) {
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { if (it.length <= 6) pinInput = it },
                            label = { Text("رمز مستر (۴ یا ۶ رقمی)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSettings(
                            settings.copy(
                                appLockEnabled = lockEnabled,
                                masterPin = pinInput
                            )
                        )
                        showSecurityDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text(strings.save)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSecurityDialog = false }) {
                    Text(strings.cancel)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 16. Permissions Dialog
    if (showPermissionsDialog) {
        val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val audioGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions()
        ) {
            // Re-renders naturally
        }

        AlertDialog(
            onDismissRequest = { showPermissionsDialog = false },
            title = { Text(strings.permissions, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.cameraPermission, color = Color.White)
                        Text(
                            if (cameraGranted) strings.permissionGranted else strings.permissionDenied,
                            color = if (cameraGranted) Color(0xFF10B981) else Color(0xFFEF4444),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.micPermission, color = Color.White)
                        Text(
                            if (audioGranted) strings.permissionGranted else strings.permissionDenied,
                            color = if (audioGranted) Color(0xFF10B981) else Color(0xFFEF4444),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = {
                            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                    ) {
                        Text(strings.grant)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPermissionsDialog = false }) {
                    Text(strings.close)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 17. Backup & Restore Dialog
    if (showBackupDialog) {
        var restoreText by remember { mutableStateOf("") }
        var isRestoring by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text(strings.backupRestore, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            scope.launch {
                                val json = viewModel.exportBackupJson()
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Backup", json))
                                Toast.makeText(context, strings.backupCopied, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.exportBackup)
                    }

                    OutlinedTextField(
                        value = restoreText,
                        onValueChange = { restoreText = it },
                        label = { Text("کد JSON پشتیبان را اینجا جای‌گذاری کنید") },
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        maxLines = 5
                    )

                    Button(
                        onClick = {
                            if (restoreText.isNotBlank()) {
                                scope.launch {
                                    val success = viewModel.restoreBackupJson(restoreText)
                                    if (success) {
                                        Toast.makeText(context, strings.restoreSuccess, Toast.LENGTH_SHORT).show()
                                        showBackupDialog = false
                                    } else {
                                        Toast.makeText(context, strings.restoreFailed, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text(strings.importBackup)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBackupDialog = false }) {
                    Text(strings.close)
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }

    // 19. About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text(strings.about, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("WebView App Builder", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("نسخه: ۱.۰.۰ (Build 100)", color = Color.White, fontSize = 13.sp)
                    Text("محیط اجرایی: Kotlin + Jetpack Compose + Java Core Security", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "این نرم‌افزار امکان تبدیل وب‌سایت‌ها و کدهای HTML به برنامه‌های بومی اندروید با پروفایل‌های مرورگر کاملاً مستقل، مدیریت چند حساب کاربری و صفحه‌کلید چندزبانه را فراهم می‌کند.",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text(strings.ok, color = Color(0xFF38BDF8))
                }
            },
            containerColor = Color(0xFF1E293B)
        )
    }
}

@Composable
private fun SettingsCardItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = Color(0xFF64748B),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
