package com.example.ui.launcher

import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.AppFolder
import com.example.data.model.WebAppItem
import com.example.viewmodel.AppViewModel
import java.io.File

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    onOpenApp: (WebAppItem) -> Unit,
    onOpenSettings: () -> Unit = {},
    onOpenHtmlBuilder: () -> Unit = {},
    onOpenAddApp: () -> Unit = {},
    onOpenWallpaper: () -> Unit = {},
    onOpenTabs: () -> Unit = {},
    onOpenBookmarks: () -> Unit = {},
    onOpenWebViewSettings: () -> Unit = {},
    onOpenAppearance: () -> Unit = {},
    onConvertToApk: (WebAppItem) -> Unit = {}
) {
    val context = LocalContext.current
    val allApps by viewModel.allApps.collectAsState()
    val allFolders by viewModel.allFolders.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var showAddAppDialog by remember { mutableStateOf(false) }
    var showFolderDialog by remember { mutableStateOf(false) }
    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var selectedFolder by remember { mutableStateOf<AppFolder?>(null) }
    var editingApp by remember { mutableStateOf<WebAppItem?>(null) }
    var unlockingApp by remember { mutableStateOf<WebAppItem?>(null) }

    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 5 })

    val iconShape: Shape = when (settings.iconShape) {
        "CIRCLE" -> CircleShape
        "ROUNDED_SQUARE" -> RoundedCornerShape(16.dp)
        "SQUARE" -> RoundedCornerShape(4.dp)
        else -> RoundedCornerShape(20.dp) // Squircle
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. DYNAMIC WALLPAPER
        when (settings.wallpaperType) {
            "DEFAULT" -> {
                Image(
                    painter = painterResource(id = R.drawable.mountain_wallpaper),
                    contentDescription = "Mountain Wallpaper",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            "IMAGE" -> {
                val imageFile = File(settings.wallpaperValue)
                if (imageFile.exists()) {
                    AsyncImage(
                        model = imageFile,
                        contentDescription = "Custom Wallpaper",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Image(
                        painter = painterResource(id = R.drawable.mountain_wallpaper),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            "GRADIENT" -> {
                val brush = when (settings.wallpaperValue) {
                    "GRADIENT_SUNSET" -> Brush.verticalGradient(listOf(Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)))
                    "GRADIENT_AURORA" -> Brush.verticalGradient(listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)))
                    "GRADIENT_NEON" -> Brush.verticalGradient(listOf(Color(0xFF0575E6), Color(0xFF00F260)))
                    else -> Brush.verticalGradient(listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6), Color(0xFF06B6D4)))
                }
                Box(modifier = Modifier.fillMaxSize().background(brush))
            }
            "COLOR" -> {
                val color = try {
                    Color(android.graphics.Color.parseColor(settings.wallpaperValue))
                } catch (e: Exception) {
                    Color(0xFF0B101E)
                }
                Box(modifier = Modifier.fillMaxSize().background(color))
            }
            else -> {
                Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0B101E)))
            }
        }

        // Overlay scrim with customizable panel opacity
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = (1f - settings.panelOpacity).coerceIn(0.15f, 0.75f)))
        )

        // 2. MAIN CONTENT
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Clean Android Launcher Top Bar with ONLY Settings icon
            LauncherTopBar(
                onOpenSettings = onOpenSettings
            )

            // Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (searchQuery.isEmpty()) "جستجو در برنامه‌ها..." else searchQuery,
                            color = Color.White.copy(alpha = if (searchQuery.isEmpty()) 0.6f else 1f),
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // App Grid with Horizontal Pager
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                val visibleApps = allApps
                    .filter { !it.isHidden && it.folderId == null && (searchQuery.isNotEmpty() || it.pageIndex == page) }
                    .filter { it.name.contains(searchQuery, ignoreCase = true) }
                    .sortedBy { it.orderIndex }

                val visibleFolders = allFolders
                    .filter { searchQuery.isNotEmpty() || it.pageIndex == page }
                    .filter { it.name.contains(searchQuery, ignoreCase = true) }
                    .sortedBy { it.orderIndex }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(settings.columnCount),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Apps on this page
                    items(visibleApps, key = { "app_${it.id}" }) { app ->
                        AppGridItem(
                            app = app,
                            shape = iconShape,
                            onClick = {
                                if (app.isLocked && !app.pinCode.isNullOrEmpty()) {
                                    unlockingApp = app
                                } else {
                                    viewModel.markAppUsed(app.id)
                                    onOpenApp(app)
                                }
                            },
                            onLongClick = { editingApp = app }
                        )
                    }

                    // Folders on this page
                    items(visibleFolders, key = { "folder_${it.id}" }) { folder ->
                        val appsInFolder = allApps.filter { it.folderId == folder.id }
                        FolderGridItem(
                            folder = folder,
                            appsInFolder = appsInFolder,
                            shape = iconShape,
                            onClick = {
                                selectedFolder = folder
                                showFolderDialog = true
                            }
                        )
                    }
                }
            }

            // Page Indicator Dots (5 dots matching mockup)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(5) { index ->
                    val isSelected = pagerState.currentPage == index
                    Box(
                        modifier = Modifier
                            .padding(3.dp)
                            .size(if (isSelected) 8.dp else 5.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.White else Color.White.copy(alpha = 0.35f))
                    )
                }
            }

            // Bottom Dock (matching screen 1: Phone, Messages, Chrome/Browser, Camera)
            BottomDockBar(
                onOpenBrowser = {
                    val defaultBrowserApp = allApps.firstOrNull { it.name.contains("YouTube", ignoreCase = true) }
                        ?: allApps.firstOrNull()
                        ?: WebAppItem(name = "مرورگر", type = "WEB_URL", targetUrl = "https://www.google.com")
                    onOpenApp(defaultBrowserApp)
                },
                onOpenPhone = {
                    try {
                        val intent = Intent(Intent.ACTION_DIAL)
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                },
                onOpenMessages = {
                    try {
                        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_APP_MESSAGING) }
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                },
                onOpenCamera = {
                    try {
                        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            )
        }

        // Folder Dialog (Screen 6 in mockups)
        if (showFolderDialog && selectedFolder != null) {
            FolderDialog(
                folder = selectedFolder!!,
                appsInFolder = allApps.filter { it.folderId == selectedFolder!!.id },
                onDismiss = {
                    showFolderDialog = false
                    selectedFolder = null
                },
                onOpenApp = { app ->
                    showFolderDialog = false
                    selectedFolder = null
                    if (app.isLocked && !app.pinCode.isNullOrEmpty()) {
                        unlockingApp = app
                    } else {
                        viewModel.markAppUsed(app.id)
                        onOpenApp(app)
                    }
                },
                onDeleteFolder = { folder ->
                    viewModel.deleteFolder(folder)
                    showFolderDialog = false
                    selectedFolder = null
                },
                onUpdateFolder = { updated ->
                    viewModel.updateFolder(updated)
                },
                onRemoveAppFromFolder = { app ->
                    viewModel.moveAppToFolder(app.id, null)
                }
            )
        }

        // Edit App Dialog
        if (editingApp != null) {
            EditAppDialog(
                appItem = editingApp!!,
                folders = allFolders,
                totalPages = 5,
                onDismiss = { editingApp = null },
                onSave = { updated ->
                    viewModel.updateApp(updated)
                    editingApp = null
                },
                onDelete = { app ->
                    viewModel.deleteApp(app)
                    editingApp = null
                },
                onClearData = { app ->
                    viewModel.clearWebAppData(app.id)
                },
                onConvertToApk = { app ->
                    editingApp = null
                    onConvertToApk(app)
                }
            )
        }

        // Unlock PIN Dialog
        if (unlockingApp != null) {
            PinLockDialog(
                correctPin = unlockingApp!!.pinCode ?: "",
                title = "قفل برنامه: ${unlockingApp!!.name}",
                onUnlocked = {
                    val app = unlockingApp!!
                    unlockingApp = null
                    viewModel.markAppUsed(app.id)
                    onOpenApp(app)
                },
                onDismiss = { unlockingApp = null }
            )
        }
    }
}

@Composable
fun LauncherTopBar(
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.35f),
            modifier = Modifier.size(44.dp)
        ) {
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppGridItem(
    app: WebAppItem,
    shape: Shape,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(4.dp)
            .testTag("app_item_${app.id}")
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            BrandAppIcon(
                app = app,
                size = 56.dp,
                shape = shape
            )

            if (app.isLocked) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = Color.Yellow,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = app.name,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun FolderGridItem(
    folder: AppFolder,
    appsInFolder: List<WebAppItem>,
    shape: Shape,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
            .testTag("folder_item_${folder.id}")
    ) {
        val folderColor = try {
            Color(android.graphics.Color.parseColor(folder.colorHex))
        } catch (e: Exception) {
            Color(0xFF3B82F6)
        }

        Surface(
            modifier = Modifier.size(56.dp),
            shape = shape,
            color = folderColor.copy(alpha = 0.25f),
            border = androidx.compose.foundation.BorderStroke(1.dp, folderColor.copy(alpha = 0.5f))
        ) {
            // 2x2 mini icons grid preview inside folder (matching mockup screen 1)
            Box(
                modifier = Modifier.fillMaxSize().padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                if (appsInFolder.isEmpty()) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = folder.name,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            appsInFolder.getOrNull(0)?.let { MiniIcon(it) }
                            appsInFolder.getOrNull(1)?.let { MiniIcon(it) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            appsInFolder.getOrNull(2)?.let { MiniIcon(it) }
                            appsInFolder.getOrNull(3)?.let { MiniIcon(it) }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = folder.name,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun MiniIcon(app: WebAppItem) {
    BrandAppIcon(
        app = app,
        size = 18.dp,
        shape = RoundedCornerShape(4.dp)
    )
}

@Composable
fun BottomDockBar(
    onOpenBrowser: () -> Unit,
    onOpenPhone: () -> Unit,
    onOpenMessages: () -> Unit,
    onOpenCamera: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 8.dp)
    ) {
        Surface(
            color = Color.White.copy(alpha = 0.18f),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().height(68.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Phone (green)
                DockIcon(
                    icon = Icons.Default.Call,
                    bgColor = Color(0xFF22C55E),
                    onClick = onOpenPhone
                )
                // Messages (blue)
                DockIcon(
                    icon = Icons.Default.Chat,
                    bgColor = Color(0xFF3B82F6),
                    onClick = onOpenMessages
                )
                // Browser / Chrome (gradient/globe)
                DockIcon(
                    icon = Icons.Default.Language,
                    bgColor = Color(0xFFF59E0B),
                    onClick = onOpenBrowser
                )
                // Camera (dark gray)
                DockIcon(
                    icon = Icons.Default.CameraAlt,
                    bgColor = Color(0xFF334155),
                    onClick = onOpenCamera
                )
            }
        }
    }
}

@Composable
fun DockIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    bgColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(bgColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(24.dp)
        )
    }
}
